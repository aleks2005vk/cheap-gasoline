import React, { useEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom/client';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-routing-machine';
import 'leaflet-routing-machine/dist/leaflet-routing-machine.css';
import 'leaflet.markercluster';
import 'leaflet.markercluster/dist/MarkerCluster.css';
import 'leaflet.markercluster/dist/MarkerCluster.Default.css';
import MapSidebar from './MapSidebar';
import BannerLeft from './BannerLeft';
import BannerBottom from './BannerBottom';
import PopupAd from './PopupAd';
import { pointsOfInterest } from './points';
import { useLocation, useNavigate } from 'react-router-dom';

const PopupContent = ({ point }) => {
  // show prices if present
  const fuelPrices = point.parsedData
    ? [
        { name: 'Regular', price: point.parsedData.prices.regular ?? '-' },
        { name: 'Premium', price: point.parsedData.prices.premium ?? '-' },
        { name: 'Diesel', price: point.parsedData.prices.diesel ?? '-' },
      ]
    : [
        { name: 'ნანო პრემიუმი', price: 2.40 },
        { name: 'ნანო ევრო რეგულარი', price: 2.30 },
        { name: 'ნანო ევრო დიზელი', price: 2.55 },
      ];

  return (
    <div style={{ textAlign: 'center', maxWidth: 220 }}>
      <h3 style={{ marginBottom: 6 }}>{point.name}</h3>
      {point.image && (
        <img src={point.image} alt={point.name} style={{ width: '120px', height: 'auto', marginBottom: 6 }} />
      )}
      <p style={{ fontSize: 12, margin: '6px 0' }}>{point.description}</p>

      <div style={{ borderTop: '1px solid #ddd', paddingTop: 6 }}>
        {fuelPrices.map((fuel, i) => (
          <p key={i} style={{ margin: '2px 0', fontSize: 13 }}>
            <strong style={{ display: 'inline-block', width: 80 }}>{fuel.name}:</strong>{' '}
            <span>{fuel.price}</span>
          </p>
        ))}
      </div>
    </div>
  );
};

const MapComponent = () => {
  const mapRef = useRef(null);
  const markersRef = useRef(new Map()); // pointId -> marker
  const [selectedPoint, setSelectedPoint] = useState(null);
  const [userLocation, setUserLocation] = useState(null);
  const [showPopup, setShowPopup] = useState(false);

  const location = useLocation();
  const navigate = useNavigate();

  // if AddStationPhoto navigated with parsedData/photo, we set attach mode
  const [attachMode, setAttachMode] = useState(false);
  const [dataToAttach, setDataToAttach] = useState(null);
  const [isMobile, setIsMobile] = useState(false);
  const [showSidebar, setShowSidebar] = useState(true);

  useEffect(() => {
    if (location?.state?.parsedData) {
      setAttachMode(true);
      setDataToAttach({ parsedData: location.state.parsedData, photo: location.state.photo });
      // remove state from history to avoid re-trigger on refresh
      window.history.replaceState({}, '');
    }
  }, [location]);

  // determine mobile breakpoint and default sidebar visibility
  useEffect(() => {
    const check = () => {
      const mobile = typeof window !== 'undefined' && window.innerWidth < 768;
      setIsMobile(mobile);
      // hide sidebar by default on mobile
      setShowSidebar(!mobile);
    };
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const centerToUser = () => {
    if (mapRef.current && userLocation) {
      mapRef.current.setView([userLocation.lat, userLocation.lng], 14);
    }
  };

  // Improved GPS location request (used for initial lookup)
  const requestUserLocation = (options = {}) => {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        console.warn('Geolocation not supported');
        resolve({ latitude: 41.769, longitude: 44.784 });
        return;
      }

      const geoOptions = {
        enableHighAccuracy: options.enableHighAccuracy !== false,
        timeout: options.timeout || 10000,
        maximumAge: options.maximumAge || 0,
      };

      let handled = false;

      const success = (position) => {
        if (handled) return;
        handled = true;
        const { latitude, longitude, accuracy } = position.coords;
        console.log(`GPS: lat=${latitude}, lng=${longitude}, accuracy=${accuracy}m`);
        resolve({ latitude, longitude, accuracy });
      };

      const fail = (error) => {
        if (handled) return;
        handled = true;
        console.warn(`GPS Error (${error.code}): ${error.message}`);
        resolve({ latitude: 41.7151, longitude: 44.8271 });
      };

      navigator.geolocation.getCurrentPosition(success, fail, geoOptions);

      // safety: after timeout resolve fallback
      setTimeout(() => {
        if (!handled) {
          handled = true;
          resolve({ latitude: 41.7151, longitude: 44.8271 });
        }
      }, geoOptions.timeout + 500);
    });
  };

  useEffect(() => {
    if (mapRef.current) return;

    mapRef.current = L.map('map', {
      center: [41.769, 44.784],
      zoom: 14,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(mapRef.current);

    const markerClusterGroup = L.markerClusterGroup();

    // try to get user location (with improved request)
    requestUserLocation({ enableHighAccuracy: true, timeout: 8000 }).then((loc) => {
      const { latitude, longitude } = loc;
      setUserLocation({ lat: latitude, lng: longitude });
      try {
        mapRef.current.setView([latitude, longitude], 14);
        L.marker([latitude, longitude])
          .addTo(mapRef.current)
          .bindPopup('📍 Ваша позиция');
      } catch (err) {
        console.warn('Error setting map view for user location', err);
      }
    });

    // create markers
    pointsOfInterest.forEach((point) => {
      const marker = L.marker([point.lat, point.lng]);

      // store mapping pointId -> marker
      if (point.id != null) markersRef.current.set(point.id, marker);

      // create popup container and render React content into it
      const popupContainer = L.DomUtil.create('div');
      ReactDOM.createRoot(popupContainer).render(<PopupContent point={point} />);
      marker.bindPopup(popupContainer);

      marker.on('click', (e) => {
        // if attach mode — attach parsed data to this point
        if (attachMode && dataToAttach) {
          // attach to in-memory point object
          point.parsedData = dataToAttach.parsedData;
          if (dataToAttach.photo) point.image = dataToAttach.photo;
          // save to localStorage as record for persistence
          const submissions = JSON.parse(localStorage.getItem('stationPhotos') || '[]');
          submissions.push({
            pointId: point.id ?? `${point.lat}_${point.lng}`,
            pointName: point.name,
            parsedData: dataToAttach.parsedData,
            photo: dataToAttach.photo,
            timestamp: new Date().toISOString(),
          });
          localStorage.setItem('stationPhotos', JSON.stringify(submissions));

          // re-render popup content for this marker
          const newContainer = L.DomUtil.create('div');
          ReactDOM.createRoot(newContainer).render(<PopupContent point={point} />);
          marker.setPopupContent(newContainer);
          marker.openPopup();

          alert(`Данные успешно привязаны к ${point.name}`);
          // exit attach mode (optional) — если нужно привязать несколько отметь оставить attachMode true
          setAttachMode(false);
          setDataToAttach(null);
          // navigate to main map without state (we already replaced history earlier, but double safe)
          navigate('/', { replace: true });
          return;
        }

        // normal select behavior
        setSelectedPoint(point);
      });

      markerClusterGroup.addLayer(marker);
    });

    mapRef.current.addLayer(markerClusterGroup);

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [attachMode, dataToAttach, navigate]);

  // small UI element showing attach instructions
  const AttachBanner = () => {
    if (!attachMode || !dataToAttach) return null;
    return (
      <div style={{ position: 'absolute', left: 14, top: 14, zIndex: 9999 }}>
        <div className="bg-yellow-400 text-black px-4 py-2 rounded shadow">
          <div className="text-sm font-semibold">Режим привязки</div>
          <div className="text-xs mt-1">Нажми на маркер на карте, чтобы привязать распознанные цены к заправке.</div>
          <div className="mt-2 flex gap-2">
            <button
              onClick={() => {
                // cancel attach mode
                setAttachMode(false);
                setDataToAttach(null);
              }}
              className="px-2 py-1 bg-white rounded text-sm"
            >
              Отменить
            </button>
            <button
              onClick={() => {
                // optionally zoom to user or first marker
                centerToUser();
              }}
              className="px-2 py-1 bg-white rounded text-sm"
            >
              Центр на меня
            </button>
          </div>
        </div>
      </div>
    );
  };

  useEffect(() => {
    const id = setTimeout(() => setShowPopup(true), 2200);
    return () => clearTimeout(id);
  }, []);

  return (
    <div className="w-full h-[80vh] md:h-[50vh] relative">
      <AttachBanner />

      <div className="flex flex-col md:flex-row h-full">
        <BannerLeft />

        <div className="flex-1 flex" style={{ gap: 0 }}>
          <div id="map" className={`flex-1 h-full relative z-0 rounded-l-lg shadow-inner overflow-hidden`}>
            <button
              onClick={centerToUser}
              title="Center to my location"
              style={{ position: 'absolute', right: 12, bottom: 12, zIndex: 2000 }}
              className="bg-white p-2 rounded-full shadow hover:bg-gray-100"
            >
              📍
            </button>
            {/* Sidebar toggle button */}
            <button
              onClick={() => setShowSidebar((s) => !s)}
              title={showSidebar ? 'Скрыть список' : 'Показать список'}
              style={{ position: 'absolute', left: 12, top: 12, zIndex: 2200 }}
              className="bg-white p-2 rounded-full shadow hover:bg-gray-100"
            >
              {showSidebar ? '☰' : '☰'}
            </button>

            {/* Mobile drawer for sidebar: render above map so it doesn't push map out */}
            {isMobile && showSidebar && (
              <div className="absolute top-0 right-0 h-full w-3/4 max-w-sm z-30 bg-white shadow-lg overflow-auto">
                <div className="p-2 border-b flex items-center justify-between">
                  <div className="font-semibold">Список заправок</div>
                  <button className="px-2 py-1" onClick={() => setShowSidebar(false)}>
                    Закрыть
                  </button>
                </div>
                <MapSidebar
                  points={pointsOfInterest}
                  onPointClick={(point) => {
                    setSelectedPoint(point);
                    setShowSidebar(false);
                    if (mapRef.current) {
                      mapRef.current.setView([point.lat, point.lng], 15);
                      const marker = markersRef.current.get(point.id);
                      if (marker) marker.openPopup();
                    }
                  }}
                  selectedPoint={selectedPoint}
                  userLocation={userLocation}
                />
              </div>
            )}
          </div>

          {/* Desktop sidebar (keeps original layout) */}
          {!isMobile && showSidebar && (
            <div className="w-full md:w-80">
              <MapSidebar
                points={pointsOfInterest}
                onPointClick={(point) => {
                  setSelectedPoint(point);
                  if (mapRef.current) {
                    mapRef.current.setView([point.lat, point.lng], 15);
                    const marker = markersRef.current.get(point.id);
                    if (marker) marker.openPopup();
                  }
                }}
                selectedPoint={selectedPoint}
                userLocation={userLocation}
              />
            </div>
          )}
        </div>
      </div>

      <div style={{ height: 76 }} className="w-full flex items-center justify-center">
        <BannerBottom />
      </div>

      <PopupAd open={showPopup} onClose={() => setShowPopup(false)} />
    </div>
  );
};

export default MapComponent;
